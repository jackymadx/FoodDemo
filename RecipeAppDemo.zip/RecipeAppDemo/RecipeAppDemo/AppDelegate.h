//
//  AppDelegate.h
//  RecipeAppDemo
//
//  Created by Jacky Chan on 06/03/2017.
//  Copyright © 2017 MadX Studio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

