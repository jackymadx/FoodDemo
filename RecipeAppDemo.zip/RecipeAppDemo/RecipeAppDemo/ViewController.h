//
//  ViewController.h
//  RecipeAppDemo
//
//  Created by Jacky Chan on 06/03/2017.
//  Copyright © 2017 MadX Studio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak,nonatomic) IBOutlet UIButton *btnAdd;
@property (weak,nonatomic) IBOutlet UIButton *btnDelete;
@property (weak,nonatomic) IBOutlet UIButton *btnUpdate;
@property (weak,nonatomic) IBOutlet UIButton *btnList;

- (IBAction)doAdd:(id)sender;
- (IBAction)doDelete:(id)sender;
- (IBAction)doUpdate:(id)sender;
- (IBAction)doList:(id)sender;

@end

