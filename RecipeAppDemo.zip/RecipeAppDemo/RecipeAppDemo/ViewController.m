//
//  ViewController.m
//  RecipeAppDemo
//
//  Created by Jacky Chan on 06/03/2017.
//  Copyright © 2017 MadX Studio. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize btnAdd;
@synthesize btnDelete;
@synthesize btnUpdate;
@synthesize btnList;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSLog(@"[RecipeApp]>>");
    
}

- (IBAction)doList:(id)sender {
    NSLog(@" %s",__FUNCTION__);
}

- (IBAction)doAdd:(id)sender {
     NSLog(@" %s",__FUNCTION__);
}

- (IBAction)doUpdate:(id)sender {
     NSLog(@" %s",__FUNCTION__);
}

- (IBAction)doDelete:(id)sender {
     NSLog(@" %s",__FUNCTION__);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    self.btnAdd    = nil;
    self.btnList   = nil;
    self.btnUpdate = nil;
    self.btnDelete = nil;
}

@end
